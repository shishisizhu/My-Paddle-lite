// Copyright (c) 2020 PaddlePaddle Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <vector>
#include "lite/core/tensor.h"

namespace paddle {
namespace lite {
namespace loongarch {
namespace math {

// to-do(qili93): need to remove after avx2 complete
void bias_add_broadcast(const float* dinx,
                        const float* diny,
                        float* dout,
                        int batch,
                        int channels,
                        int num);

void bias_add_relu_broadcast(const float* dinx,
                             const float* diny,
                             float* dout,
                             int batch,
                             int channels,
                             int num);

void bias_add_relu6_broadcast(const float* dinx,
                              const float* diny,
                              float* dout,
                              int batch,
                              int channels,
                              int num);

}  // namespace math
}  // namespace loongarch
}  // namespace lite
}  // namespace paddle
